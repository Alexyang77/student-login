using System.Collections.Generic;
using IdentityExample.Models;

namespace IdentityExample.ViewModels
{
    public class ProfileViewModel
    {
        public string UserId { get; set; } 

        public List<Course> AllCourses { get; set; }

        public List<Course> RegisteredCourses { get; set; }
    }
}