﻿using System.Security.Cryptography;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using IdentityExample.Data;
using Microsoft.AspNetCore.Identity;
using IdentityExample.Models;
using System.Security.Claims;
using IdentityExample.ViewModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace IdentityExample.Controllers
{
    public class StudentController : Controller
    {
        private StudentContext _studentContext;
        private UserManager<Student> _userManager;
        private ILogger<StudentController> _logger;

        public StudentController(StudentContext studentContext, UserManager<Student> userManager, ILogger<StudentController> logger)
        {
            _studentContext = studentContext;
            _userManager = userManager;
            _logger = logger;
        }

        [Authorize]
        public IActionResult Index()
        {
            return View();
        }

        [Authorize]
        public async Task<IActionResult> Profile([FromQuery]string action, [FromQuery]int courseId)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = await _userManager.FindByIdAsync(userId);
                _logger.LogInformation($"{courseId}");

            if (!string.IsNullOrWhiteSpace(action))
            {
                var course = await _studentContext.Courses.FindAsync(courseId);
                var courseStudent = new CourseStudent() { Course = course, Student = user };

                switch (action)
                {
                    case "register":
                        await _studentContext.CourseStudents.AddAsync(courseStudent);
                        await _studentContext.SaveChangesAsync();
                        break;
                    case "deregister":
                        _studentContext.CourseStudents.Remove(courseStudent);
                        await _studentContext.SaveChangesAsync();
                        break;
                }
            }

            var viewModel = new ProfileViewModel()
            {
                UserId = userId,
                AllCourses = await _studentContext.Courses.ToListAsync(),
                RegisteredCourses = await _studentContext.CourseStudents
                    .Where(cs => cs.StudentId == userId)
                    .Select(cs => cs.Course)
                    .ToListAsync()
            };

            return View(viewModel);
        }

        [AllowAnonymous]
        public IActionResult CourseDetails()
        {
            return View(_studentContext.Courses.ToList());
        }
    }
}