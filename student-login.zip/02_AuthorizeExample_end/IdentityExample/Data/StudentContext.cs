﻿using System.ComponentModel.DataAnnotations;
using IdentityExample.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityExample.Data
{
    public class StudentContext : IdentityDbContext<Student>
    {
        public StudentContext(DbContextOptions<StudentContext> options)
            : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<CourseStudent> CourseStudents { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<CourseStudent>()
                .HasKey(cs => new { cs.CourseId, cs.StudentId });

            modelBuilder.Entity<CourseStudent>()
                .HasIndex(cs => new { cs.CourseId, cs.StudentId })
                .IsUnique();

            modelBuilder.Entity<CourseStudent>()
                .HasOne(cs => cs.Course)
                .WithMany(c => c.CourseStudents)
                .HasForeignKey(cs => cs.CourseId);

            modelBuilder.Entity<CourseStudent>()
                .HasOne(cs => cs.Student)
                .WithMany(s => s.CourseStudents)
                .HasForeignKey(cs => cs.StudentId);

            modelBuilder.Entity<Course>().HasData(
            new Course
            {
                Id = 1,
                Name = "Accounting & Finance"
            },
            new Course
            {
                Id = 2,
                Name = "Archaeology & Anthropology"
            },
            new Course
            {
                Id = 3,
                Name = "Biology"
            },
            new Course
            {
                Id = 4,
                Name = "Chemistry"
            },
            new Course
            {
                Id = 5,
                Name = "Engineering Science"
            });
        }
    }
}
